
import { QueryClientProvider } from "@tanstack/react-query";
import { useEffect } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { TooltipProvider } from "@/components/ui/tooltip";
import { queryClient } from "./lib/queryClient";
import { ScrollArea } from "@/components/ui/scroll-area";
import QuranPage from "./pages/QuranPage";

export default function App() {
  useEffect(() => {
    document.title = "Quran Reading Application";
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <BrowserRouter>
          <ScrollArea className="h-screen">
            <Routes>
              <Route path="/" element={<QuranPage />} />
            </Routes>
          </ScrollArea>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
}
