import { useState, useEffect } from "react";

type Theme = "dark" | "light"

function getSystemTheme(): Theme {
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
}

export function useTheme() {
  const [theme, setTheme] = useState<Theme>(() => {
    // Check local storage first
    const stored = localStorage.getItem("theme") as Theme | null
    return stored || getSystemTheme()
  })

  useEffect(() => {
    localStorage.setItem("theme", theme)
    document.documentElement.classList.remove("light", "dark")
    document.documentElement.classList.add(theme)
  }, [theme])

  return { theme, setTheme }
}