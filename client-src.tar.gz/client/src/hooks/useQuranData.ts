
import { useQuery } from "@tanstack/react-query";

export function useQuranData() {
  return useQuery({
    queryKey: ["/api/quran"],
  });
}
