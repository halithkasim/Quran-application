
import { useQuranData } from "@/hooks/useQuranData";
import { useState } from "react";
import { Surah } from "./SurahPage";

export default function QuranPage() {
  const { data, isLoading, error } = useQuranData();
  const [selectedSurah, setSelectedSurah] = useState<number | null>(null);

  if (isLoading) return <div className="p-8 text-center">Loading...</div>;
  if (error) return <div className="p-8 text-center text-red-500">Error loading Quran data</div>;
  if (!data) return <div className="p-8 text-center">No data available</div>;

  if (selectedSurah !== null) {
    const surah = data.data.surahs.find(s => s.number === selectedSurah);
    if (surah) {
      return (
        <Surah 
          surah={surah} 
          onBack={() => setSelectedSurah(null)} 
        />
      );
    }
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="mb-6 text-3xl font-bold text-center">Quran Surahs</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {data.data.surahs.map((surah) => (
          <div 
            key={surah.number} 
            className="border rounded-lg p-4 cursor-pointer hover:bg-gray-50 transition-colors"
            onClick={() => setSelectedSurah(surah.number)}
          >
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xl font-semibold">{surah.englishName}</h2>
                <p className="text-gray-600">{surah.englishNameTranslation}</p>
                <p className="text-sm text-gray-500">Verses: {surah.ayahs.length}</p>
              </div>
              <div className="text-2xl font-arabic">{surah.name}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
