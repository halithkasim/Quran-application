
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

type Ayah = {
  number: number;
  text: string;
  numberInSurah: number;
  juz: number;
  page: number;
};

type SurahType = {
  number: number;
  name: string;
  englishName: string;
  englishNameTranslation: string;
  revelationType: string;
  ayahs: Ayah[];
};

interface SurahProps {
  surah: SurahType;
  onBack: () => void;
}

export function Surah({ surah, onBack }: SurahProps) {
  return (
    <div className="container mx-auto p-4">
      <Button 
        variant="ghost" 
        onClick={onBack}
        className="mb-4"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Surahs
      </Button>
      
      <div className="mb-6 text-center">
        <h1 className="text-3xl font-bold">{surah.englishName}</h1>
        <p className="text-xl text-gray-600">{surah.englishNameTranslation}</p>
        <div className="text-3xl font-arabic mt-2">{surah.name}</div>
        <p className="text-sm text-gray-500 mt-1">Revelation Type: {surah.revelationType}</p>
      </div>
      
      <div className="space-y-6">
        {surah.ayahs.map((ayah) => (
          <div key={ayah.number} className="border rounded-lg p-4">
            <div className="flex justify-between items-start mb-2">
              <span className="bg-gray-200 text-gray-700 rounded-full h-8 w-8 flex items-center justify-center">
                {ayah.numberInSurah}
              </span>
              <div className="text-xs text-gray-500">
                Page {ayah.page} | Juz {ayah.juz}
              </div>
            </div>
            <p className="text-right text-xl font-arabic leading-loose mb-2">{ayah.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
