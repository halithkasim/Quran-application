import { Link } from "wouter";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

const hadithCollections = [
  {
    id: "bukhari",
    name: "صحيح البخاري",
    englishName: "Sahih al-Bukhari",
    description: "The most authentic collection of hadith compiled by Imam Muhammad al-Bukhari"
  },
  {
    id: "muslim",
    name: "صحيح مسلم",
    englishName: "Sahih Muslim",
    description: "A collection of authentic hadith compiled by Imam Muslim ibn al-Hajjaj"
  },
  {
    id: "abudawud",
    name: "سنن أبي داود",
    englishName: "Sunan Abu Dawud",
    description: "One of the six major hadith collections compiled by Abu Dawud"
  },
  {
    id: "tirmidhi",
    name: "جامع الترمذي",
    englishName: "Jami at-Tirmidhi",
    description: "A prominent collection of hadith compiled by Imam at-Tirmidhi"
  }
];

export default function HadithCollections() {
  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Hadith Collections</h1>
        <p className="text-muted-foreground">
          Explore authentic collections of Prophetic traditions
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {hadithCollections.map((collection) => (
          <Link key={collection.id} href={`/hadith/${collection.id}`}>
            <Card className="hover:bg-accent cursor-pointer transition-colors">
              <CardHeader>
                <CardTitle className="flex flex-col gap-2">
                  <span className="text-2xl">{collection.englishName}</span>
                  <span className="text-xl text-primary">{collection.name}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {collection.description}
                </p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
