import { Link } from "wouter";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import SearchBar from "@/components/SearchBar";
import { quranData, searchQuran, loadQuranData } from "@/lib/quran";
import { useState, useEffect } from "react";
import type { Verse } from "@shared/schema";

export default function Home() {
  const [searchResults, setSearchResults] = useState<(Verse & { 
    surahNumber?: number;
    surahName?: string;
    surahEnglishName?: string;
  })[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function initialize() {
      try {
        await loadQuranData();
        setIsLoading(false);
      } catch (err) {
        setError("Failed to load Quran data. Please try again later.");
        setIsLoading(false);
      }
    }
    initialize();
  }, []);

  const handleSearch = (query: string) => {
    if (query.trim()) {
      const results = searchQuran(query.trim());
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading Quran data...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold text-red-600 mb-4">Error</h1>
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Noble Quran</h1>
        <p className="text-muted-foreground">
          Read, reflect, and listen to the Holy Quran
        </p>
      </div>

      <div className="max-w-2xl mx-auto">
        <SearchBar onSearch={handleSearch} />
      </div>

      {searchResults.length > 0 ? (
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold">Search Results</h2>
          {searchResults.map((verse, index) => (
            <Link 
              key={index} 
              href={`/surah/${verse.surahNumber || 1}`}
            >
              <Card className="hover:bg-accent cursor-pointer transition-colors">
                <CardContent className="p-6">
                  {verse.surahName && (
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-lg font-semibold">{verse.surahEnglishName}</span>
                      <span className="text-lg font-semibold text-primary">{verse.surahName}</span>
                    </div>
                  )}
                  <p className="text-xl text-right mb-2">{verse.text}</p>
                  <p className="text-muted-foreground">{verse.translation}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {quranData.map((chapter) => (
            <Link key={chapter.number} href={`/surah/${chapter.number}`}>
              <Card className="hover:bg-accent cursor-pointer transition-colors">
                <CardHeader>
                  <CardTitle className="flex justify-between items-center">
                    <span>{chapter.englishName}</span>
                    <span className="text-primary">{chapter.name}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    {chapter.versesCount} verses
                  </p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}