import { useParams } from "wouter";
import { getChapter } from "@/lib/quran";
import QuranReader from "@/components/QuranReader";
import { Button } from "@/components/ui/button";
import { ChevronLeft } from "lucide-react";
import { Link } from "wouter";
import { useState, useEffect } from "react";
import { Loader2 } from "lucide-react";
import type { Chapter } from "@shared/schema";

export default function Surah() {
  const { number } = useParams<{ number: string }>();
  const [chapter, setChapter] = useState<Chapter | undefined>();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadChapter() {
      const chapterData = await getChapter(parseInt(number));
      setChapter(chapterData);
      setIsLoading(false);
    }
    loadChapter();
  }, [number]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading chapter...</span>
      </div>
    );
  }

  if (!chapter) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold mb-4">Surah not found</h1>
        <Link href="/">
          <Button>
            <ChevronLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <Link href="/">
          <Button variant="ghost">
            <ChevronLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
        </Link>
      </div>

      <QuranReader chapter={chapter} />
    </div>
  );
}