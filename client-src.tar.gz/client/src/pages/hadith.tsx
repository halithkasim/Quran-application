import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import { getHadithCollection } from "@/lib/hadith";
import type { HadithCollection } from "@shared/schema";
import SearchBar from "@/components/SearchBar";

export default function HadithPage() {
  const { collection } = useParams<{ collection: string }>();
  const [hadithData, setHadithData] = useState<HadithCollection | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadHadithData() {
      try {
        const data = await getHadithCollection(collection);
        setHadithData(data);
        setIsLoading(false);
      } catch (err) {
        setError("Failed to load hadith data. Please try again later.");
        setIsLoading(false);
      }
    }
    loadHadithData();
  }, [collection]);

  const handleSearch = async (query: string) => {
    setIsLoading(true);
    try {
      const results = await searchHadith(query, collection);
      // Handle search results
      setIsLoading(false);
    } catch (err) {
      setError("Failed to search hadiths. Please try again.");
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading hadith collection...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold text-red-600 mb-4">Error</h1>
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold">
          {hadithData?.englishName || "Hadith Collection"}
        </h1>
        <p className="text-muted-foreground">
          {hadithData?.name}
        </p>
      </div>

      <div className="max-w-2xl mx-auto">
        <SearchBar onSearch={handleSearch} />
      </div>

      <div className="space-y-4">
        {hadithData?.hadiths.map((hadith, index) => (
          <Card key={index}>
            <CardContent className="p-6 space-y-4">
              <div className="flex justify-between items-start">
                <span className="text-sm text-muted-foreground">
                  {hadith.reference}
                </span>
                {hadith.grade && (
                  <span className="text-sm font-medium bg-primary/10 text-primary px-2 py-1 rounded">
                    {hadith.grade}
                  </span>
                )}
              </div>
              
              <div>
                <p className="text-lg mb-2 font-semibold">{hadith.englishNarrator}</p>
                <p className="text-right mb-4 font-arabic">{hadith.arabicNarrator}</p>
              </div>

              <div>
                <p className="text-lg mb-2">{hadith.englishText}</p>
                <p className="text-right font-arabic">{hadith.arabicText}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
