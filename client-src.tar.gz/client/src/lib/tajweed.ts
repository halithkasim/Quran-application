import React from 'react';

// Tajweed Rules with their corresponding colors
export const tajweedRules = {
  ghunnah: { name: "Ghunnah", color: "bg-blue-200/40", description: "Nasalization" },
  ikhfa: { name: "Ikhfa", color: "bg-green-200/40", description: "Hidden Noon/Tanween" },
  idgham: { name: "Idgham", color: "bg-purple-200/40", description: "Merging" },
  qalqalah: { name: "Qalqalah", color: "bg-yellow-200/40", description: "Bouncing Sound" },
  madd: { name: "Madd", color: "bg-red-200/40", description: "Elongation" },
} as const;

// Characters for each rule
const ghunnahChars = ['ن', 'م'];
const ikhfaChars = ['ت', 'ث', 'ج', 'د', 'ذ', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ف', 'ق', 'ك'];
const idghamChars = ['ي', 'ن', 'م', 'و', 'ل', 'ر'];
const qalqalahChars = ['ق', 'ط', 'ب', 'ج', 'د'];
const maddChars = ['ا', 'و', 'ي'];

interface TajweedMark {
  rule: keyof typeof tajweedRules;
  start: number;
  end: number;
}

export function analyzeTajweed(text: string): TajweedMark[] {
  const marks: TajweedMark[] = [];
  const chars = Array.from(text);

  for (let i = 0; i < chars.length; i++) {
    const char = chars[i];
    const nextChar = chars[i + 1];

    // Check for Ghunnah
    if (ghunnahChars.includes(char) && nextChar === 'ّ') {
      marks.push({ rule: 'ghunnah', start: i, end: i + 2 });
    }

    // Check for Ikhfa
    if (char === 'ن' && nextChar && ikhfaChars.includes(nextChar)) {
      marks.push({ rule: 'ikhfa', start: i, end: i + 2 });
    }

    // Check for Idgham
    if (char === 'ن' && nextChar && idghamChars.includes(nextChar)) {
      marks.push({ rule: 'idgham', start: i, end: i + 2 });
    }

    // Check for Qalqalah
    if (qalqalahChars.includes(char) && (!nextChar || !isVowel(nextChar))) {
      marks.push({ rule: 'qalqalah', start: i, end: i + 1 });
    }

    // Check for Madd
    if (maddChars.includes(char) && nextChar === 'ۡ') {
      marks.push({ rule: 'madd', start: i, end: i + 2 });
    }
  }

  return marks;
}

function isVowel(char: string): boolean {
  return ['َ', 'ِ', 'ُ', 'ً', 'ٍ', 'ٌ'].includes(char);
}

export function highlightTajweed(text: string): React.ReactNode[] {
  const marks = analyzeTajweed(text);
  const result: React.ReactNode[] = [];
  const chars = Array.from(text);
  let currentIndex = 0;

  marks.sort((a, b) => a.start - b.start);

  for (let i = 0; i < marks.length; i++) {
    const mark = marks[i];

    // Add any text before this mark
    if (mark.start > currentIndex) {
      result.push(
        chars.slice(currentIndex, mark.start).join('')
      );
    }

    // Add the marked text
    const rule = tajweedRules[mark.rule];
    const markedText = chars.slice(mark.start, mark.end).join('');

    result.push(
      React.createElement('span', {
        key: `mark-${i}`,
        className: `${rule.color} rounded px-0.5`,
        title: `${rule.name}: ${rule.description}`,
      }, markedText)
    );

    currentIndex = mark.end;
  }

  // Add any remaining text
  if (currentIndex < chars.length) {
    result.push(chars.slice(currentIndex).join(''));
  }

  return result;
}