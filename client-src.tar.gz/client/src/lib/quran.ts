import type { Chapter, Verse } from "@shared/schema";
import { initDB, storeChapter, getOfflineChapter, isChapterAvailableOffline, storeAudio, getAudio } from './offlineDb';

interface AlQuranResponse {
  code: number;
  status: string;
  data: {
    surahs: Array<{
      number: number;
      name: string;
      englishName: string;
      numberOfAyahs: number;
      ayahs: Array<{
        number: number;
        text: string;
        numberInSurah: number;
        audio: string;
      }>;
    }>;
  };
}

export let quranData: Chapter[] = [];

export async function loadQuranData() {
  try {
    // Initialize IndexedDB
    await initDB();

    // Try to load from network first
    try {
      const response = await fetch('/api/quran');
      const data: AlQuranResponse = await response.json();

      quranData = data.data.surahs.map(surah => ({
        number: surah.number,
        name: surah.name,
        englishName: surah.englishName,
        versesCount: surah.numberOfAyahs,
        verses: surah.ayahs.map(ayah => ({
          number: ayah.numberInSurah,
          text: ayah.text,
          translation: "", // We'll need another API call for translations
          audioUrl: ayah.audio
        }))
      }));

      // Store each chapter offline
      await Promise.all(quranData.map(chapter => storeChapter(chapter)));

      return quranData;
    } catch (networkError) {
      console.log('Network error, falling back to offline data:', networkError);
      // If network request fails, try to load from IndexedDB
      const offlineChapters: Chapter[] = [];
      for (let i = 1; i <= 114; i++) {
        const chapter = await getOfflineChapter(i);
        if (chapter) {
          offlineChapters.push(chapter);
        }
      }

      if (offlineChapters.length > 0) {
        quranData = offlineChapters;
        return quranData;
      }

      throw new Error('No offline data available');
    }
  } catch (error) {
    console.error('Error loading Quran data:', error);
    throw error;
  }
}

export async function getChapter(number: number): Promise<Chapter | undefined> {
  // Check if the chapter is in memory
  const memoryChapter = quranData.find(chapter => chapter.number === number);
  if (memoryChapter) return memoryChapter;

  // If not in memory, try to get from offline storage
  return await getOfflineChapter(number);
}

export function searchQuran(query: string): Verse[] {
  const results: Verse[] = [];
  const searchLower = query.toLowerCase().trim();

  quranData.forEach(chapter => {
    // If query matches surah name or english name, include all verses
    if (
      chapter.name.toLowerCase().includes(searchLower) ||
      chapter.englishName.toLowerCase().includes(searchLower)
    ) {
      results.push(...chapter.verses);
      return;
    }

    // Search through individual verses
    chapter.verses.forEach(verse => {
      if (
        verse.text.includes(query) || // Keep exact match for Arabic
        verse.translation.toLowerCase().includes(searchLower)
      ) {
        results.push({
          ...verse,
          surahNumber: chapter.number, // Add surah context
          surahName: chapter.name,
          surahEnglishName: chapter.englishName
        });
      }
    });
  });

  // Limit results to prevent overwhelming the UI
  return results.slice(0, 20);
}

// New function to pre-download audio
export async function preloadAudio(url: string) {
  try {
    // Check if audio is already cached
    const cachedAudio = await getAudio(url);
    if (cachedAudio) return;

    // If not cached, download and store
    const response = await fetch(url);
    const audioBlob = await response.blob();
    await storeAudio(url, audioBlob);
  } catch (error) {
    console.error('Error preloading audio:', error);
  }
}