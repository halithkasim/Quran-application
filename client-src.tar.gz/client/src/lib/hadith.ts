import type { HadithCollection } from "@shared/schema";

export async function getHadithCollection(collection: string): Promise<HadithCollection | null> {
  try {
    const response = await fetch(`/api/hadith/${collection}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch hadith collection: ${response.statusText}`);
    }
    const data = await response.json();
    return data.data;
  } catch (error) {
    console.error('Error fetching hadith collection:', error);
    return null;
  }
}

export async function searchHadith(query: string, collection?: string): Promise<any[]> {
  try {
    const url = collection 
      ? `/api/hadith/${collection}/search?q=${encodeURIComponent(query)}`
      : `/api/hadith/search?q=${encodeURIComponent(query)}`;
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to search hadith: ${response.statusText}`);
    }
    const data = await response.json();
    return data.data;
  } catch (error) {
    console.error('Error searching hadith:', error);
    return [];
  }
}
