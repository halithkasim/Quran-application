import { openDB, type IDBPDatabase } from 'idb';
import type { Chapter, Verse } from '@shared/schema';

const DB_NAME = 'quran_offline_db';
const DB_VERSION = 1;

interface QuranDB extends IDBPDatabase {
  chapters: Chapter[];
  verses: Verse[];
  bookmarks: any[];
}

export async function initDB() {
  const db = await openDB<QuranDB>(DB_NAME, DB_VERSION, {
    upgrade(db) {
      // Create object stores
      if (!db.objectStoreNames.contains('chapters')) {
        db.createObjectStore('chapters', { keyPath: 'number' });
      }
      if (!db.objectStoreNames.contains('verses')) {
        db.createObjectStore('verses', { keyPath: ['chapterNumber', 'number'] });
      }
      if (!db.objectStoreNames.contains('bookmarks')) {
        db.createObjectStore('bookmarks', { keyPath: 'id', autoIncrement: true });
      }
      if (!db.objectStoreNames.contains('audio')) {
        db.createObjectStore('audio');
      }
    },
  });

  return db;
}

export async function storeChapter(chapter: Chapter) {
  const db = await initDB();
  const tx = db.transaction('chapters', 'readwrite');
  await tx.store.put(chapter);
  
  // Store verses separately
  const versesTx = db.transaction('verses', 'readwrite');
  await Promise.all(
    chapter.verses.map((verse) => 
      versesTx.store.put({
        ...verse,
        chapterNumber: chapter.number
      })
    )
  );
}

export async function getOfflineChapter(number: number): Promise<Chapter | undefined> {
  const db = await initDB();
  return db.get('chapters', number);
}

export async function storeAudio(key: string, audioBlob: Blob) {
  const db = await initDB();
  await db.put('audio', audioBlob, key);
}

export async function getAudio(key: string): Promise<Blob | undefined> {
  const db = await initDB();
  return db.get('audio', key);
}

export async function isChapterAvailableOffline(number: number): Promise<boolean> {
  const db = await initDB();
  const chapter = await db.get('chapters', number);
  return !!chapter;
}
