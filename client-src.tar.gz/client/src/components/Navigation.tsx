import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Moon, Sun, Book } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";

export default function Navigation() {
  const { theme, setTheme } = useTheme();

  return (
    <nav className="border-b">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <span className="text-2xl font-bold text-primary">قرآن</span>
        </Link>

        <div className="flex items-center gap-4">
          <Link href="/hadith/bukhari">
            <Button variant="ghost" className="flex items-center gap-2">
              <Book className="h-5 w-5" />
              <span>Hadith</span>
            </Button>
          </Link>

          <Button
            variant="ghost"
            size="icon"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
        </div>
      </div>
    </nav>
  );
}