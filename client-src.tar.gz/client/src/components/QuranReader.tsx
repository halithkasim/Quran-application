import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bookmark } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Chapter, Verse } from "@shared/schema";
import AudioPlayer from "./AudioPlayer";
import { preloadAudio } from "@/lib/quran";
import { highlightTajweed, tajweedRules } from "@/lib/tajweed";

interface QuranReaderProps {
  chapter: Chapter;
}

export default function QuranReader({ chapter }: QuranReaderProps) {
  const [currentVerseIndex, setCurrentVerseIndex] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Preload next verse's audio
  useEffect(() => {
    if (currentVerseIndex < chapter.verses.length - 1) {
      const nextVerse = chapter.verses[currentVerseIndex + 1];
      if (nextVerse.audioUrl) {
        preloadAudio(nextVerse.audioUrl);
      }
    }
  }, [currentVerseIndex, chapter.verses]);

  const bookmarkMutation = useMutation({
    mutationFn: async (verse: Verse) => {
      await apiRequest("POST", "/api/bookmarks", {
        surahNumber: chapter.number,
        ayahNumber: verse.number,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookmarks"] });
      toast({
        title: "Bookmark added",
        description: "The verse has been bookmarked successfully.",
      });
    },
  });

  const handleVerseEnd = () => {
    if (currentVerseIndex < chapter.verses.length - 1) {
      setCurrentVerseIndex((prev) => prev + 1);
      // Scroll to the next verse
      const nextVerseElement = document.getElementById(`verse-${currentVerseIndex + 1}`);
      if (nextVerseElement) {
        nextVerseElement.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4 rtl">
        <h1 className="text-4xl font-bold">{chapter.name}</h1>
        <p className="text-xl text-muted-foreground">{chapter.englishName}</p>
      </div>

      {/* Tajweed Rules Legend */}
      <Card className="p-4">
        <h3 className="font-semibold mb-2">Tajweed Rules</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
          {Object.entries(tajweedRules).map(([key, rule]) => (
            <div
              key={key}
              className={`${rule.color} rounded p-2 text-sm flex flex-col items-center text-center`}
            >
              <span className="font-semibold">{rule.name}</span>
              <span className="text-xs text-muted-foreground">{rule.description}</span>
            </div>
          ))}
        </div>
      </Card>

      <div className="space-y-4">
        {chapter.verses.map((verse, index) => (
          <Card 
            key={verse.number} 
            id={`verse-${index}`}
            className={`p-6 transition-colors ${index === currentVerseIndex ? 'ring-2 ring-primary' : ''}`}
          >
            <div className="flex justify-between items-start gap-4">
              <div className="flex-1 space-y-4">
                <p className="text-2xl leading-relaxed text-right font-arabic">
                  {highlightTajweed(verse.text)}
                </p>
                <p className="text-muted-foreground">{verse.translation}</p>
              </div>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => bookmarkMutation.mutate(verse)}
              >
                <Bookmark className="h-5 w-5" />
              </Button>
            </div>

            {verse.audioUrl && index === currentVerseIndex && (
              <div className="mt-4">
                <AudioPlayer 
                  src={verse.audioUrl} 
                  onEnded={handleVerseEnd}
                />
              </div>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
}