import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, Volume2, VolumeX } from "lucide-react";
import { getAudio } from "@/lib/offlineDb";

interface AudioPlayerProps {
  src: string;
  onEnded?: () => void;
}

export default function AudioPlayer({ src, onEnded }: AudioPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Auto-play when src changes
  useEffect(() => {
    async function setupAudio() {
      if (audioRef.current) {
        try {
          // Try to get cached audio first
          const cachedAudio = await getAudio(src);
          if (cachedAudio) {
            const objectUrl = URL.createObjectURL(cachedAudio);
            audioRef.current.src = objectUrl;
          } else {
            audioRef.current.src = src;
          }

          audioRef.current.play().catch(error => {
            console.log('Auto-play prevented:', error);
          });
          setIsPlaying(true);
        } catch (error) {
          console.error('Error setting up audio:', error);
          // Fallback to online source
          audioRef.current.src = src;
        }
      }
    }
    setupAudio();
  }, [src]);

  // Cleanup object URL when component unmounts or src changes
  useEffect(() => {
    return () => {
      if (audioRef.current?.src.startsWith('blob:')) {
        URL.revokeObjectURL(audioRef.current.src);
      }
    };
  }, [src]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      const progress = (audioRef.current.currentTime / audioRef.current.duration) * 100;
      setProgress(progress);
    }
  };

  const handleEnded = () => {
    setIsPlaying(false);
    setProgress(0);
    if (onEnded) {
      onEnded();
    }
  };

  return (
    <div className="flex items-center gap-4 p-4 bg-card rounded-lg">
      <Button variant="ghost" size="icon" onClick={togglePlay}>
        {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
      </Button>

      <Slider
        value={[progress]}
        max={100}
        step={1}
        className="w-full"
        onValueChange={(value) => {
          if (audioRef.current) {
            const time = (value[0] / 100) * audioRef.current.duration;
            audioRef.current.currentTime = time;
            setProgress(value[0]);
          }
        }}
      />

      <Button variant="ghost" size="icon" onClick={toggleMute}>
        {isMuted ? <VolumeX className="h-6 w-6" /> : <Volume2 className="h-6 w-6" />}
      </Button>

      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onEnded={handleEnded}
      />
    </div>
  );
}